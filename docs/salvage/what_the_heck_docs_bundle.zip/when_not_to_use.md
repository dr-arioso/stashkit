# When NOT to Use This Pattern

Do NOT use this pattern if:

- Your data is authoritative and static
- Identity is guaranteed at ingestion
- History does not matter
- Overwrites are acceptable
- Performance requires aggressive collapse

Examples:
- Simple CRUD apps
- Configuration stores
- Transactional ledgers

This pattern trades simplicity for epistemic honesty.

Use it only when uncertainty is real and costly to ignore.