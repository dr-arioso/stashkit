# Start Here 👋

This folder contains a set of short orientation documents explaining **what this system is**, **who it’s for**, and **when not to use it**.

If you’re confused, you’re in the right place.

Markdown **does support hyperlinks**, and the links below will work anywhere Markdown is rendered (GitHub, GitLab, most docs sites).

---

## Pick the path that fits you

### 🧑‍💻 Software / Systems Developers
If you build systems that ingest messy, real-world data and are tired of “last overwrite wins”:

➡️ **Start here:**  
[What the Heck Is This Thing? (Developer Intro)](what_the_heck_is_this.md)

Then read:
- [Two Bottles, One Identity](two_bottles_walkthrough.md)

---

### 🧪 Scientific / Research Users
If you work with experiments, observations, provenance, or evolving hypotheses:

➡️ **Start here:**  
[What the Heck Is This Thing? (Scientific Audience)](what_the_heck_science.md)

---

### 📊 Data / ML / Product Teams
If you deal with noisy signals, probabilistic labels, or changing conclusions:

➡️ **Start here:**  
[What the Heck Is This Thing? (Data / ML / Product)](what_the_heck_data.md)

---

## Core reference material

Once the idea clicks, these apply to everyone:

- [Single‑Page Concept Diagram](diagram_single_page.md)
- [When *Not* to Use This Pattern](when_not_to_use.md)

---

## One sentence summary

> **This system treats identity as a hypothesis supported by evidence, preserves all observations, and reconciles them into usable views only when needed.**

If that sentence made sense, you’re ready for the rest of the documentation.