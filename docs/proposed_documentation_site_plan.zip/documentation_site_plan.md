# Full Documentation Site Plan for Barback / StashKit / MetaDex 1.4

This document outlines a complete plan for converting the existing documentation into a full developer documentation site using **MkDocs + Material**. The goal is to support onboarding, conceptual understanding, ontology reference, API guides, and subsystem integration for StashKit, Barback, MetaDex, AppDex Architect, DexPort, UXDex, and ADA.

---

## 1. Build System: MkDocs + Material Theme

**Why MkDocs?**
- Markdown-first workflow.
- Simple configuration.
- Great for ontology + API + conceptual documentation.
- Flexible navigation.

**Why Material Theme?**
- Best-in-class UX.
- Search, tabs, versioning, deep navigation.
- Dark mode, code highlighting, great typography.

**Install:**
```bash
pip install mkdocs mkdocs-material
```

**Initialize:**
```bash
mkdocs new docs_site
```

Later, rename or replace the generated files with the structure below.

---

## 2. Documentation Structure (Information Architecture)

Proposed folder layout under `docs/`:

```
docs/
  index.md
  getting-started/
    barback_quickstart.md
    stashkit_quickstart.md
  concepts/
    stashkit_concepts.md
    barback_concepts.md
    metadex_concepts.md
    appdex_architect_concepts.md
    dexport_uxdex_ada_overview.md
  reference/
    cli_reference.md
    python_api_reference.md
    metadex_api_schema.md
    metadex_entities.md (auto-generated)
    metadex_relationships.md (auto-generated)
  internals/
    architecture.md
    metadex_compiler_pipeline.md
    how_gpt_should_load_metadex.md
  guides/
    adding_a_new_resolver.md
    writing_a_new_skill.md
    extending_metadex.md
    appdex_modeling_with_barback.md
  changelog.md
```

This separates conceptual docs from reference docs, tutorials, onboarding, and internals.

---

## 3. Navigation (mkdocs.yml)

Example:

```yaml
site_name: Barback & StashKit
theme:
  name: material

nav:
  - Home: index.md
  - Getting Started:
      - Barback Quickstart: getting-started/barback_quickstart.md
      - StashKit Quickstart: getting-started/stashkit_quickstart.md
  - Concepts:
      - StashKit Concepts: concepts/stashkit_concepts.md
      - Barback Concepts: concepts/barback_concepts.md
      - MetaDex: concepts/metadex_concepts.md
      - AppDex Architect: concepts/appdex_architect_concepts.md
      - DexPort + UXDex + ADA: concepts/dexport_uxdex_ada_overview.md
  - Reference:
      - CLI Reference: reference/cli_reference.md
      - Python API Reference: reference/python_api_reference.md
      - MetaDex API Schema: reference/metadex_api_schema.md
      - MetaDex Entities: reference/metadex_entities.md
      - MetaDex Relationships: reference/metadex_relationships.md
  - Internals:
      - Architecture: internals/architecture.md
      - MetaDex Compiler Pipeline: internals/metadex_compiler_pipeline.md
      - GPT Onboarding: internals/how_gpt_should_load_metadex.md
  - Guides:
      - Adding a New Resolver: guides/adding_a_new_resolver.md
      - Writing a New Skill: guides/writing_a_new_skill.md
      - Extending MetaDex: guides/extending_metadex.md
      - AppDex Modeling with Barback: guides/appdex_modeling_with_barback.md
  - Changelog: changelog.md
```

---

## 4. Integrate Existing Docs

Your current files map as follows:

| Original File | New Target |
|---------------|------------|
| README.md | `docs/index.md` |
| STASHKIT_CONCEPTUAL_OVERVIEW.md | `concepts/stashkit_concepts.md` |
| METADEX_API_SCHEMA.md | `reference/metadex_api_schema.md` |
| METADEX_COMPILER_PIPELINE.md | `internals/metadex_compiler_pipeline.md` |
| architecture.mmd | embed as `internals/architecture.md` |
| ONBOARDING_FOR_GPT.md | `internals/how_gpt_should_load_metadex.md` |

Only light editing is required for these moves.

---

## 5. Auto-Generated Reference Docs from MetaDex

Write a script such as `tools/generate_docs_from_metadex.py`:

### Responsibilities:
- Read `metadex.json`
- Build:
  - `reference/metadex_entities.md`
  - `reference/metadex_relationships.md`

### Example entity entry:

```markdown
### stashkit.resolver
**Type:** class  
**Description:** Resolves input artifacts into StashCards.  
**Public API:**
- `resolve()`
```

This ensures reference docs always match the current MetaDex ontology.

---

## 6. Developer Guides to Support Adoption

Short, example-driven documents:

- **Adding a New Resolver**  
  Walk through writing a custom Resolver + Skills.

- **Writing a New Skill**  
  Show how to define a Skill, parameters, outputs.

- **Extending MetaDex**  
  For users who want to enrich the ontology.

- **AppDex Modeling**  
  How to produce an AppDex model for Barback (or their own apps).

---

## 7. Versioning and Deployment

### Deployment:
GitHub Pages is the simplest:

```bash
mkdocs gh-deploy
```

### Versioning (optional):
Use mkdocs-material versioning plugin or keep version numbers inside the docs.

---

## 8. GPT-Specific Documentation

MetaDex is consumed by GPT.  
Include a page detailing:

- How GPT should selectively load subsystems
- How to avoid context over-pollution
- Expected behaviors when using MetaDex as a state initializer

This acts as an onboarding tool for *your future AI assistants* as well.

---

## 9. Summary

The site will provide:

- Clear learning paths for new users
- Accurate reference info synced to MetaDex
- Guides and examples for practical use
- Internal docs for ontology/compiler design
- Rich conceptual docs for AppDex Architect, DexPort, UXDex, and ADA

This is a reliable, scalable foundation for Barback, StashKit, and the broader ecosystem.

